# Firecrack :fire:

What is firecrack tools ?
Firecrack tools are tools for testing and testing on websites or Facebook accounts, conducting<br>
testing on hundreds of Facebook accounts with random accounts and random wordlist, and there are<br>
for testing websites, such as admin finder and deface with file upload method, and Bing dorking<br>
to collect Many domains, Bing Dorking is useful if you are collecting a lot of domains.<br>
more tools: :point_down:<br>
<br>firecrack fiture:<br>

```
1.hack facebook (random attack)
2.bruteforce facebook (one account)
3.admin finder
4.bing dorking
5.deface (file upload)
```

## :camera: Screenshot:
![1](https://github.com/Ranginang67/Firecrack/blob/master/img/1.png)
![2](https://github.com/Ranginang67/Firecrack/blob/master/img/2.png)
![3](https://github.com/Ranginang67/Firecrack/blob/master/img/3.png)
## :mag_right: admin finder:
![4](https://github.com/Ranginang67/Firecrack/blob/master/img/admin_pan.png)
## :page_with_curl: bing dorking:
![5](https://github.com/Ranginang67/Firecrack/blob/master/img/dorking.png)
## :game_die: facebook hacking random attack:
![6](https://github.com/Ranginang67/Firecrack/blob/master/img/random_1.png)
![7](https://github.com/Ranginang67/Firecrack/blob/master/img/random_2.png)
## :globe_with_meridians: deface:
![8](https://github.com/Ranginang67/Firecrack/blob/master/img/deface.png)

## install and usage:

**Termux:**
* `pkg install python2`
* `pkg install git`
* `git clone https://github.com/RanaMZ/target.git`
* `cd Firecrack`
* `pip2 install -r requirements.txt`
* `python2 firecrack.py`
* `help`

**Linux:**
* `apt-get install python`
* `apt-get install python-pip`
* `apt-get install git`
* `git clone https://github.com/RanaMZ/target.git`
* `cd Firecrack`
* `pip install -r requirements.txt`
* `python firecrack.py`
* `help`

```
NOTE:

1.before use facebook random attack, edit file "nano module/wordlist.txt" and add your wordlist minim of 5 line
2.before use firecrack deface, put your deface script one folder with firecrack.py
```

# support me

<a href="https://www.youtube.com/channel/UCNMD5U02GFeWLqmrl_XSPGQ"><img src="https://img.shields.io/badge/subcribe-YouTube-red.svg"> <a href="https://t.me/Msambari"><img src="https://img.shields.io/badge/telegram-Ms.ambari-blue.svg">
